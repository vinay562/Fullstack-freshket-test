const Calculator = require('../calculator');

describe('Calculator', () => {
  test('Test Case 1: Calculate price without member card', () => {
    expect(Calculator.calculatePrice(['Red set', 'Green set'], false)).toBe(90);
  });

  test('Test Case 2: Calculate price with member card', () => {
    expect(Calculator.calculatePrice(['Red set', 'Green set'], true)).toBe(81);
  });

  test('Test Case 3: Calculate price with Orange set discount', () => {
    expect(Calculator.calculatePrice(['Orange set', 'Orange set'], false)).toBe(228);
  });

  test('Test Case 4: Calculate price with Pink set discount', () => {
    expect(Calculator.calculatePrice(['Pink set', 'Pink set'], false)).toBe(152);
  });

  test('Test Case 5: Calculate price with Green set discount', () => {
    expect(Calculator.calculatePrice(['Green set', 'Green set'], false)).toBe(76);
  });

  test('Test Case 6: Calculate price with Blue set', () => {
    expect(Calculator.calculatePrice(['Blue set'], false)).toBe(30);
  });

  test('Test Case 7: Calculate price with Yellow set and Pink set', () => {
    expect(Calculator.calculatePrice(['Yellow set', 'Pink set'], false)).toBe(130);
  });

  test('Test Case 8: Calculate price with Purple set and Orange set', () => {
    expect(Calculator.calculatePrice(['Purple set', 'Orange set'], false)).toBe(210);
  });

  test('Test Case 9: Calculate price with all sets and member card', () => {
    expect(
      Calculator.calculatePrice(
        ['Red set', 'Green set', 'Blue set', 'Yellow set', 'Pink set', 'Purple set', 'Orange set'],
        true
      )
    ).toBe(414);
  });

  test('Test Case 10: Calculate price with an empty order', () => {
    expect(Calculator.calculatePrice([], false)).toBe(0);
  });
});
