const Calculator = require('./calculator'); 

const order = ['Red set', 'Blue set', 'Orange set']; // you can change the menu to check different out put.
const hasMemberCard = true;

const totalPrice = Calculator.calculatePrice(order, hasMemberCard);

console.log(`Total Price: ${totalPrice}`);