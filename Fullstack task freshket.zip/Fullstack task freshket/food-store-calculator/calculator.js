// This code is by Vinay Kumar Jaiswal (Full Stack Developer)
class Calculator {
    static calculatePrice(order, hasMemberCard) {
      const menuPrices = {
        'Red set': 50,
        'Green set': 40,
        'Blue set': 30,
        'Yellow set': 50,
        'Pink set': 80,
        'Purple set': 90,
        'Orange set': 120,
      };
  
      let totalPrice = order.reduce((total, item) => total + menuPrices[item], 0); //logic to calculate total price
  
      // Logic to apply discount for Orange, Pink, and Green sets if ordered in pairs
      order.forEach((item) => {
        if (item === 'Orange set' || item === 'Pink set' || item === 'Green set') {
          const itemCount = order.filter((i) => i === item).length;
          const discount = Math.floor(itemCount / 2) * (menuPrices[item] * 0.05);
          totalPrice -= discount;
        }
      });
  
      // Apply 10% discount for members
      if (hasMemberCard) {
        totalPrice *= 0.9;
      }
  
      return Math.round(totalPrice); // Rounding off 
    }
  }
  
  module.exports = Calculator;
  