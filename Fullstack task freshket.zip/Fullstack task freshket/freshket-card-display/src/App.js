import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';

const App = () => {
  const [places, setPlaces] = useState([]);
  const [tags, setTags] = useState([]);

  useEffect(() => {
    const fetchPlaces = async () => {
      try {
        const placesResponse = await axios.get(
          'https://gist.githubusercontent.com/knot-freshket/142c21c3e8e54ef36e33f5dc6cf54077/raw/94ebab16839484f06d42eb799e30d0a945ff1a1b/freshket-places.json'
        );
        setPlaces(placesResponse.data);
      } catch (error) {
        console.error('Error fetching places:', error);
      }
    };

    const fetchTags = async () => {
      try {
        const tagsResponse = await axios.get(
          'https://gist.githubusercontent.com/knot-freshket/fa49e0a5c6100d50db781f28486324d2/raw/55bc966f54423dc73384b860a305e1b67e0bfd7d/freshket-tags.json'
        );
        setTags(tagsResponse.data);
      } catch (error) {
        console.error('Error fetching tags:', error);
      }
    };

    fetchPlaces();
    fetchTags();
  }, []);

  return (
    <div className="card-container">
      {places.map((place, index) => (
        <div key={index} className="card">
          <img src={place.img_url} alt={place.name} className="card-image" />
          <div className="card-content">
            <div className="card-name-container">
              <h2 className="card-name">{place.name}</h2>
            </div>
            <p className="card-description">{place.body}</p>
            <div className="tag-chips">
              {place.tags.map((tagId, tagIndex) => (
                <span key={tagIndex} className="tag-chip">
                  {tags.find((tag) => tag.id === tagId)?.name}
                </span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default App;
